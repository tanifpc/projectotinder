

// Run this script on debug stoping in the line just bellow you.
// Try to guess what is the output of every console.log

// Variables

var x = 0 // variable of type int
var y = 1.0 // variable of type float(decimal)
var z = "xpto" // variable of type string(text)
var f = true // variable of type boolean(true or false)

console.log(x) // 0
console.log(y) // 1.0
console.log(z) // xpto
console.log(f)

// Variable Assigment

var r = 1

console.log(r) // 1

r = x 

console.log(r) // 0

var h = 10

console.log(h) // 10

h = r = z

console.log(h) // xpto
console.log(r) // xpto

// Operations

var v1 = 10
var v2 = 10.0
var v3 = "xpto"

var r1 = v1+v1
var r2 = v1-v1
var r3 = v1*v1
var r4 = v1/v1
var r5 = v1%v1

console.log(r1) // 20
console.log(r2) // 0
console.log(r3) // 100
console.log(r4) // 1
console.log(r5) // 0

var r6 = v1+v2 
var r7 = v3+v1

console.log(r6) // 20.0
console.log(r7) // "xpto10"

// String

var xpto = "xpto"
var cenas = "cenas"

var split = xpto.split("p")
var char = xpto[2]
var concat = xpto+cenas

console.log(split) // ["x","to"]
console.log(char) // "t"
console.log(concat) // "xptocenas"

// Arrays

var empty = []
var strings = ["xpto","cenas","coisas"]
var numbers = [19,29,10,2931,9290]
var mixed = [true,"xpto",10,293.9]
var length = strings.length

console.log(strings[0]) // xpto
console.log(strings[2]) // coisas
console.log(strings[3]) // undifined
console.log(length) // 3
console.log(strings[length]) // undifined
console.log(strings[length-1]) // "coisas"

// Array operations

strings.push("rrrr")
console.log(strings[4]) // rrrr


// Diciotnaries (key value pair)

var dict1 = {
	"key1":"value1",
	"key2":10,
	"key3":10.0,
	"key4":true,
}

console.log(dict1) // {key1: "value1", key2: 10, key3: 10, key4: true}

console.log(dict1["key4"]) // true
console.log(dict1.key4) // true
console.log(dict1[0]) // undifined

// Compound statements

// if (condition)
// ... excutable code
// else if (condition)
// ... executable code
// else
// ... executable code

var p1 = 10
var p2 = 10
var p3 = "xpto"
var p4 = true
var p5 = 1.0

if(p1 == p2){
	console.log("p1 == p2");
}else{
	// never executed
}

if(p1 == p3){	
	// never executed
}else{
	console.log("else");
}

if(p1 != p3){
	console.log("p1 != p3");
}

if(p1 > p5){
	console.log("p1 > p5)");
}


// for(var i: i < something; i++){
// ... exectuable code
//}
// for(var i = limit; i >= something;i--){
// ... exectuable code
//}

var arr1 = [19,29,10,2931,9290]

for(var i=0; i<arr1.length;i++){
	item = arr1[i]
	console.log(i) // 0 1 2 3 4
	console.log(item) // 19 29 10 2931 9290
}

for(var i=arr1.length-1; i>=0;i--){
	item = arr1[i]
	console.log(i) // 4 3 2 1 0
	console.log(item) // 9290 2931 10 29 19
}

for(var i in arr1){
	item = arr1[i]
	console.log(i) // 0 1 2 3 4
	console.log(item) // 19 29 10 2931 9290
}

var i = 0;
while(i < arr1.length){
	item = arr1[i]
	console.log(i) // 0 1 2 3 4
	console.log(item) // 19 29 10 2931 9290
	i++;
}

// Functions
// Entra "porco" sai "chourico" :)

// Declarar funcao
function potenciaDeDois(porco){ // parametros a,b,c

	chourico = porco * porco;
	return chourico;
}

// Executar funcao

console.log(potenciaDeDois(5)) // 25

var pot1 = potenciaDeDois(10)

console.log(pot1) // 100

function escreveOlaNaConsola(){ // Não tem parametros

	console.log("ola"); // Não retorna nada
}

escreveOlaNaConsola() // ola

// Recursive functions
// Função que chama a ela própria

// Sequencia de fibonnaci
// fib(0) = 0
// fib(1) = 1
// fib(n) = fib(n-1)+fib(n-2)


function fib(n){
	if(n == 0){
		return 0;
	}else if(n == 1){
		return 1;
	}else{
		return fib(n-1)+fib(n-2);
	}
}

console.log(fib(1)) // 1 
console.log(fib(0)) // 0
console.log(fib(2)) // 1
console.log(fib(3)) // 2 

// Objectos
// Duas maneiras de utilizar objectos em javascript

// Metodo 1
// Declarar e instaciar na mesma instrução utilizando dicionarios
// Limitacao não podemos criar vários objectos utilizando a mesma definição(declaração)
var hondaCivic = {
	marca:"honda", // atributo
	modelo:"CRX", // atributo
	acelaracao:10,
	velocidade:0, // atributo

	acelarar:function(){ // método
		this.velocidade += this.acelaracao;
		return this.velocidade;
	},
	travar:function(){ // método
		this.velocidade = 0;
		return this.velocidade;
	}
}

hondaCivic.acelarar(); // executar funcao travar (velocidade=10)
console.log(hondaCivic.velocidade) // 10
hondaCivic.acelarar(); // (velocidade=20)
console.log(hondaCivic.velocidade) // 20
hondaCivic.acelarar(); // (velocidade=30)
console.log(hondaCivic.velocidade) // 30
hondaCivic.acelarar(); // (velocidade=40)
console.log(hondaCivic.velocidade) // 40
hondaCivic.acelarar(); // (velocidade=50)
console.log(hondaCivic.velocidade) // 50
hondaCivic.travar() // executar funcao travar (velocidade=0)
console.log(hondaCivic.velocidade) // 0

// Método 2

// Definir class
function Carro(marca,modelo,acelaracao){ // Constructor

	this.marca = marca; // Utilizar o parametro "marca" do constructor para inicializar o nosso atributo "marca"
	this.modelo = modelo; // Utilizar o parametro "modelo" do constructor para inicializar o nosso atributo "modelo"
	this.acelaracao = acelaracao; // Utilizar o parametro "acelaracao" do constructor para inicializar o nosso atributo "acelaracao"
	this.velocidade = 0; // Qualquer instancia de carro vai ser instanciada com velocidade 0

	this.acelarar = function(){ // método
		this.velocidade += this.acelaracao;
		return this.velocidade;
	}
	this.travar = function(){ // método
		this.velocidade = 0;
		return this.velocidade;
	}
}

// Instanciar objecto
var cintroenC4 = new Carro("Cintroen","C4",10);

cintroenC4.acelarar(); // executar funcao travar (velocidade=10)
console.log(cintroenC4.velocidade) // 10
cintroenC4.acelarar(); // (velocidade=20)
console.log(cintroenC4.velocidade) // 20
cintroenC4.acelarar(); // (velocidade=30)
console.log(cintroenC4.velocidade) // 30
cintroenC4.acelarar(); // (velocidade=40)
console.log(cintroenC4.velocidade) // 40
cintroenC4.acelarar(); // (velocidade=50)
console.log(cintroenC4.velocidade) // 50
cintroenC4.travar() // executar funcao travar (velocidade=0)
console.log(cintroenC4.velocidade) // 0

// Podemos criar novas instacias do objecto do tipo Carro sem ter que replicar o código
// Todas as alterações feitas na classe carro vão ser propagadas para todas as instancias da class Carro
var ferrariEnzo = new Carro("Ferrari","Enzo",50);
ferrariEnzo.acelarar(); // executar funcao travar (velocidade=50)
console.log(ferrariEnzo.velocidade) // 50
ferrariEnzo.acelarar(); // (velocidade=100)
console.log(ferrariEnzo.velocidade) // 100